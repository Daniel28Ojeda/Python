#### TreinaWeb: curso "Python - Algoritmos - Parte 1"

Repositório com o código produzido durante o curso "Python - Algoritmos - Parte 1".

#### Ferramentas utilizadas no curso:

- Python 3.6.x
- PyCharm Community Edition

#### Lista de commits
Aula | Video | Commit | Link 
------ | ------ | ------ | ------ 
Aula 02.04 | Entendendo_Manipulando_Vetores | 02.04_Entendendo_Manipulando_Vetores | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/17ae0ea40570acd8a9cbe096efd6e1cccd695d76.zip) 
Aula 03.01 | Entendendo_Implementando_Busca_Linear | 03.01_Entendendo_Implementando_Busca_Linear | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/db8b441a8914d2bd8d4e7c827ae3abe63415f2fe.zip) 
Aula 04.01 | Entendendo_Implementando_Selection_Sort | 04.01_Entendendo_Implementando_Selection_Sort | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/dfb5aa10b115b5ea20344bcea353a6dbe97dbcf1.zip) 
Aula 05.02 | Entendendo_Implementando_Busca_Binaria_PT2 | 05.02_Entendendo_Implementando_Busca_Binaria_PT2 | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/6ce611a1b9096d5c8157aa2f836ac481fd11e752.zip) 
Aula 06.03 | Analise_Assintotica_O_Que_E | 06.03_Analise_Assintotica_O_Que_E | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/a5420c1b749c012ea140bd30c1290f9c4680e2ad.zip) 
Aula 06.04 | Analise_Assintotica_Notacao_BigO | 06.04_Analise_Assintotica_Notacao_BigO | [Download](https://github.com/treinaweb/treinaweb-python-algoritmos-parte1/archive/f0ae1019cf9e772e0673c716257385f0396797cd.zip) 
