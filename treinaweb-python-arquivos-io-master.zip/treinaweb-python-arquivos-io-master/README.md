#### Lista de commits
Aula | Video | Commit | Link 
------ | ------ | ------ | ------ 
Aula 01.01 | Aplicação_Base | Aplicação base | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/71a148b8e292a08c2f8b9ebcf9e24ad591b0c67f.zip) 
Aula 03.01 | Criando_Arquivos_Python | 03.01_Criando_Arquivos_Python | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/be5ad2fdc9d20a2bebfa5570aabe92be7b3df1b8.zip) 
Aula 03.03 | Escrevendo_Dados_Arquivos | 03.03_Escrevendo_Dados_Arquivos | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/d4a16f3106ddc415fade5f6ca20c28002ee60868.zip) 
Aula 03.04 | Fechando_Arquivos | 03.04_Fechando_Arquivos | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/6c4a76106e6382dbfe97c5870f8293db2a195f88.zip) 
Aula 04.01 | Lendo_Dados_Realines | 04.01_Lendo_Dados_Realines | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/ea7222981c6ce2c285c2547fdb966f3ef155c65b.zip) 
Aula 04.03 | Buscando_Contato_Email | 04.03_Buscando_Contato_Email | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/4e8b3902c77e8ed3538dae2fd1b390314323351e.zip) 
Aula 04.04 | Removendo_Contatos | 04.04_Removendo_Contatos' | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/2651d006c85b50ea39b5013af6510ef8e2147f68.zip) 
Aula 04.05 | Refatorando_Projeto_1 | 04.05_Refatorando_Projeto_1 | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/89e01fbc81480396ba6ad9a2ce537e8e3a18f69b.zip) 
Aula 04.06 | Refatorando_Projeto_2 | 04.06_Refatorando_Projeto_2 | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/c56381ef8ecd19fc0ea628643fc283b4ca0b7347.zip) 
Aula 04.07 | Refatorando_Projeto_3 | 04.07_Refatorando_Projeto_3 | [Download](https://github.com/treinaweb/treinaweb-python-arquivos-io/archive/d9d966c9f34dac0286f8e4d1e46d8e4974f2bfe9.zip) 
