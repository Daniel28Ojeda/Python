# Hand-Web-Browser
Web Browser control using hand gestures

Hand-Web Browser
Web Browsers is a very common software application which we use everyday everyhour. Use of technology can make use of 
web browsers more simple.We know about hand gestures. Why not try hand gestures to control your browser itself?

Prerequisites:-
Anaconda (Spyder IDE)
Installed OpenCV Package

Anaconda can be installed by following the steps on --> https://conda.io/docs/installation.html
To install openCV check this--> https://stackoverflow.com/questions/23119413/how-do-i-install-python-opencv-through-conda


Open and run main.py
Enter the sites name for different gestures as asked
Now use the hand gestures to control your web browser

Built With
Anaconda(Spyder IDE)

